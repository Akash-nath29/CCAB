import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import WalletButton from "./wallet-button";
import { ThemeToggle } from "./theme-toggle";

export default function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="border-b dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link href="/">
              <a className="flex items-center">
                <span className="text-xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
                  Aptos Market
                </span>
              </a>
            </Link>

            <div className="ml-10 flex items-center space-x-4">
              <Link href="/">
                <a className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-300 ${
                  location === "/" 
                    ? "text-primary dark:text-primary" 
                    : "text-muted-foreground hover:text-primary dark:text-neutral-400 dark:hover:text-white"
                }`}>
                  Browse
                </a>
              </Link>
              <Link href="/create">
                <a className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-300 ${
                  location === "/create"
                    ? "text-primary dark:text-primary"
                    : "text-muted-foreground hover:text-primary dark:text-neutral-400 dark:hover:text-white"
                }`}>
                  Create Listing
                </a>
              </Link>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <WalletButton />
          </div>
        </div>
      </div>
    </nav>
  );
}