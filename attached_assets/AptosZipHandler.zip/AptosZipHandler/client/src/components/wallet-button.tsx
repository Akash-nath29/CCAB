import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { connectWallet, disconnectWallet, getCurrentWalletAddress } from "@/lib/aptos";

export default function WalletButton() {
  const [address, setAddress] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setAddress(getCurrentWalletAddress());
  }, []);

  const handleConnect = async () => {
    try {
      setIsConnecting(true);
      const walletAddress = await connectWallet();
      setAddress(walletAddress);
      toast({
        title: "Connected",
        description: "Wallet connected successfully",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    await disconnectWallet();
    setAddress(null);
    toast({
      title: "Disconnected",
      description: "Wallet disconnected successfully",
    });
  };

  if (address) {
    return (
      <Button
        variant="outline"
        onClick={handleDisconnect}
      >
        {address.slice(0, 6)}...{address.slice(-4)}
      </Button>
    );
  }

  return (
    <Button
      onClick={handleConnect}
      disabled={isConnecting}
    >
      {isConnecting ? "Connecting..." : "Connect Wallet"}
    </Button>
  );
}
