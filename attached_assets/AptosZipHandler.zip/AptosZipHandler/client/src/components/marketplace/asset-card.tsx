import { Asset } from "@shared/schema";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface AssetCardProps {
  asset: Asset;
  onPurchase?: () => void;
}

export function AssetCard({ asset, onPurchase }: AssetCardProps) {
  const { toast } = useToast();

  const purchaseMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/transactions", {
        assetId: asset.id,
        buyerId: 1, // Demo user
        sellerId: asset.sellerId,
      });
    },
    onSuccess: () => {
      toast({
        title: "Purchase initiated",
        description: "Transaction is being processed",
      });
      onPurchase?.();
    },
  });

  return (
    <Card className="overflow-hidden">
      <CardHeader className="p-0">
        <img
          src={asset.imageUrl}
          alt={asset.title}
          className="w-full h-48 object-cover"
        />
      </CardHeader>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <Link href={`/listing/${asset.id}`}>
            <CardTitle className="text-lg hover:text-primary cursor-pointer">
              {asset.title}
            </CardTitle>
          </Link>
          <Badge variant={asset.status === "available" ? "default" : "secondary"}>
            {asset.status}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground line-clamp-2">
          {asset.description}
        </p>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <span className="text-lg font-semibold">${asset.price}</span>
        <Button
          onClick={() => purchaseMutation.mutate()}
          disabled={asset.status !== "available" || purchaseMutation.isPending}
        >
          {purchaseMutation.isPending ? "Processing..." : "Purchase"}
        </Button>
      </CardFooter>
    </Card>
  );
}
