import { Asset } from "@shared/schema";
import { AssetCard } from "./asset-card";

interface AssetGridProps {
  assets: Asset[];
  onPurchase?: () => void;
}

export function AssetGrid({ assets, onPurchase }: AssetGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {assets.map((asset) => (
        <AssetCard key={asset.id} asset={asset} onPurchase={onPurchase} />
      ))}
    </div>
  );
}
