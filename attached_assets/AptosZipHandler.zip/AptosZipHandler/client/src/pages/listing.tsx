import { useQuery } from "@tanstack/react-query";
import { Asset } from "@shared/schema";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Listing() {
  const [, params] = useRoute("/listing/:id");
  const { toast } = useToast();

  const { data: asset, isLoading, refetch } = useQuery<Asset>({
    queryKey: [`/api/assets/${params?.id}`],
  });

  const purchaseMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/transactions", {
        assetId: asset!.id,
        buyerId: 1, // Demo user
        sellerId: asset!.sellerId,
      });
    },
    onSuccess: () => {
      toast({
        title: "Purchase initiated",
        description: "Transaction is being processed",
      });
      refetch();
    },
  });

  if (isLoading || !asset) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Skeleton className="h-[600px]" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <img
            src={asset.imageUrl}
            alt={asset.title}
            className="w-full rounded-lg"
          />
        </div>
        <div>
          <div className="flex justify-between items-start mb-4">
            <h1 className="text-4xl font-bold">{asset.title}</h1>
            <Badge variant={asset.status === "available" ? "default" : "secondary"}>
              {asset.status}
            </Badge>
          </div>
          <p className="text-lg text-muted-foreground mb-8">
            {asset.description}
          </p>
          <div className="flex justify-between items-center">
            <span className="text-3xl font-bold">${asset.price}</span>
            <Button
              size="lg"
              onClick={() => purchaseMutation.mutate()}
              disabled={asset.status !== "available" || purchaseMutation.isPending}
            >
              {purchaseMutation.isPending ? "Processing..." : "Purchase Now"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
