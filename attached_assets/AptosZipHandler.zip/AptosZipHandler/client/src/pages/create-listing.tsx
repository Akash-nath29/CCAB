import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { getCurrentWalletAddress } from "@/lib/aptos";
import { insertListingSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { AptosClient } from "aptos";

const createListingSchema = insertListingSchema.extend({
  image: z.instanceof(File, { message: "Please select an image" }).optional(),
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  price: z.string().min(1, "Price is required").refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
    message: "Price must be a positive number",
  }),
});

type CreateListingForm = z.infer<typeof createListingSchema>;

export default function CreateListing() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [imagePreview, setImagePreview] = useState<string>();
  const queryClient = useQueryClient();

  const form = useForm<CreateListingForm>({
    resolver: zodResolver(createListingSchema),
    defaultValues: {
      title: "",
      description: "",
      price: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: CreateListingForm) => {
      const currentAddress = getCurrentWalletAddress();
      if (!currentAddress) {
        throw new Error("Please connect your wallet first");
      }

      try {
        let imageUrl = "";
        if (data.image) {
          // Upload image to IPFS
          const formData = new FormData();
          formData.append("file", data.image);
          const uploadRes = await fetch("/api/upload", {
            method: "POST",
            body: formData,
          });
          if (!uploadRes.ok) throw new Error("Failed to upload image");
          const { cid } = await uploadRes.json();
          imageUrl = `https://${cid}.ipfs.dweb.link`;
        }

        // Create listing on blockchain
        const wallet = (window as any).petra;
        if (!wallet) throw new Error("Petra wallet not found!");

        const payload = {
          type: "entry_function_payload",
          function: `${import.meta.env.VITE_CONTRACT_ADDRESS}::marketplace::create_listing`,
          type_arguments: [],
          arguments: [data.title, data.description, data.price.toString(), imageUrl || ""],
        };

        // Submit transaction to blockchain
        const transaction = await wallet.signAndSubmitTransaction(payload);

        // Wait for transaction confirmation
        const client = new AptosClient(import.meta.env.VITE_APTOS_NODE_URL);
        await client.waitForTransaction(transaction.hash);

        // Create listing in backend
        await apiRequest("POST", "/api/listings", {
          ...data,
          image: imageUrl || "https://placehold.co/400x300?text=No+Image",
          seller: currentAddress,
        });

        // Invalidate listings cache
        queryClient.invalidateQueries({ queryKey: ["/api/listings"] });

        return transaction.hash;
      } catch (error: any) {
        throw new Error(error.message || "Failed to create listing");
      }
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Carbon credit listing created successfully",
      });
      navigate("/marketplace");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      form.setValue("image", file);
      const reader = new FileReader();
      reader.onload = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-2xl mx-auto"
      >
        <h1 className="text-4xl font-bold text-center mb-8 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-blue-500">
          Create Carbon Credit Listing
        </h1>

        <Card className="backdrop-blur-md bg-white dark:bg-black/20 border border-gray-300 dark:border-gray-700 shadow-lg">
          <CardContent className="pt-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit((data) => createMutation.mutate(data))} className="space-y-6">
                <div className="space-y-2">
                  <FormLabel className="text-gray-700 dark:text-gray-200 font-medium">
                    Project Image
                  </FormLabel>
                  <div className="flex items-center gap-4">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="p-3 rounded-lg border-gray-300 dark:border-gray-600 bg-white dark:bg-black/20 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300"
                    />
                    {imagePreview && (
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="w-20 h-20 object-cover rounded-lg border border-gray-300 dark:border-gray-600"
                      />
                    )}
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700 dark:text-gray-200 font-medium">
                        Project Title
                      </FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Enter project title"
                          className="p-3 rounded-lg border-gray-300 dark:border-gray-600 bg-white dark:bg-black/20 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700 dark:text-gray-200 font-medium">
                        Project Description
                      </FormLabel>
                      <FormControl>
                        <Textarea
                          {...field}
                          placeholder="Enter project details, location, and environmental impact"
                          className="h-32 p-3 rounded-lg border-gray-300 dark:border-gray-600 bg-white dark:bg-black/20 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300 resize-none"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700 dark:text-gray-200 font-medium">
                        Price (APT)
                      </FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="number"
                          step="0.1"
                          placeholder="0.00"
                          className="p-3 rounded-lg border-gray-300 dark:border-gray-600 bg-white dark:bg-black/20 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  className="w-full font-semibold bg-gradient-to-r from-purple-500 to-blue-500 hover:brightness-110 transition-all duration-300 shadow-lg p-6 rounded-lg"
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? (
                    <div className="flex items-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-white/30 border-t-white" />
                      Creating...
                    </div>
                  ) : (
                    "Create Listing"
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}