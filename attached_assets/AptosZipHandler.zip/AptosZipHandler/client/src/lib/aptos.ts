import { AptosClient } from "aptos";

// Initialize Aptos client with devnet as default
const client = new AptosClient(
  import.meta.env.VITE_APTOS_NODE_URL || "https://fullnode.devnet.aptoslabs.com"
);

let currentWalletAddress: string | null = null;

export async function connectWallet(): Promise<string> {
  try {
    // Check if Petra wallet is installed
    const wallet = (window as any).petra;
    if (!wallet) {
      throw new Error("Petra wallet not found! Please install it first.");
    }

    // Connect wallet and get account
    await wallet.connect();
    const account = await wallet.account();
    currentWalletAddress = account.address;
    return account.address;
  } catch (error: any) {
    throw new Error(`Failed to connect wallet: ${error.message}`);
  }
}

export async function disconnectWallet() {
  const wallet = (window as any).petra;
  if (wallet) {
    await wallet.disconnect();
    currentWalletAddress = null;
  }
}

export function getCurrentWalletAddress(): string | null {
  return currentWalletAddress;
}

export async function purchaseListing(listing: {
  id: number;
  price: number;
  seller: string;
}): Promise<string> {
  try {
    const wallet = (window as any).petra;
    if (!wallet) {
      throw new Error("Petra wallet not found!");
    }

    const payload = {
      type: "entry_function_payload",
      function: `${import.meta.env.VITE_CONTRACT_ADDRESS}::marketplace::buy`,
      type_arguments: [],
      arguments: [listing.id.toString(), listing.price.toString(), listing.seller],
    };

    const transaction = await wallet.signAndSubmitTransaction(payload);
    return transaction.hash;
  } catch (error: any) {
    throw new Error(`Transaction failed: ${error.message}`);
  }
}
