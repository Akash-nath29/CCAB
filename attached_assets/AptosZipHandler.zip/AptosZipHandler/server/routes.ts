import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertListingSchema, insertTransactionSchema } from "@shared/schema";

export async function registerRoutes(app: Express) {
  const httpServer = createServer(app);

  // Get all listings
  app.get("/api/listings", async (_req, res) => {
    const listings = await storage.getListings();
    res.json(listings);
  });

  // Get single listing
  app.get("/api/listings/:id", async (req, res) => {
    const listing = await storage.getListing(Number(req.params.id));
    if (!listing) {
      return res.status(404).json({ message: "Listing not found" });
    }
    res.json(listing);
  });

  // Get listings by seller
  app.get("/api/listings/seller/:address", async (req, res) => {
    const listings = await storage.getListingsBySeller(req.params.address);
    res.json(listings);
  });

  // Search listings
  app.get("/api/listings/search/:query", async (req, res) => {
    const listings = await storage.searchListings(req.params.query);
    res.json(listings);
  });

  // Create listing
  app.post("/api/listings", async (req, res) => {
    const result = insertListingSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ message: "Invalid listing data" });
    }
    const listing = await storage.createListing(result.data);
    res.status(201).json(listing);
  });

  // Delete listing
  app.delete("/api/listings/:id", async (req, res) => {
    const listing = await storage.getListing(Number(req.params.id));
    if (!listing) {
      return res.status(404).json({ message: "Listing not found" });
    }
    if (listing.seller !== req.body.seller) {
      return res.status(403).json({ message: "Not authorized" });
    }
    await storage.updateListingStatus(listing.id, "deleted");
    res.json({ message: "Listing deleted" });
  });

  // Create transaction
  app.post("/api/transactions", async (req, res) => {
    const result = insertTransactionSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ message: "Invalid transaction data" });
    }

    const listing = await storage.getListing(result.data.listingId);
    if (!listing || listing.status !== "available") {
      return res.status(400).json({ message: "Listing not available" });
    }

    const transaction = await storage.createTransaction(result.data);
    await storage.updateListingStatus(result.data.listingId, "pending");
    res.status(201).json(transaction);
  });

  // Get user transactions
  app.get("/api/transactions/user/:address", async (req, res) => {
    const transactions = await storage.getTransactionsByUser(req.params.address);
    res.json(transactions);
  });

  // Update transaction status
  app.patch("/api/transactions/:id", async (req, res) => {
    const { status, txHash } = req.body;
    const transaction = await storage.updateTransactionStatus(
      Number(req.params.id),
      status,
      txHash
    );
    if (!transaction) {
      return res.status(404).json({ message: "Transaction not found" });
    }
    res.json(transaction);
  });

  return httpServer;
}