import { 
  type User, type InsertUser,
  type Listing, type InsertListing,
  type Transaction, type InsertTransaction
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByWallet(address: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Listing operations
  getListings(): Promise<Listing[]>;
  getListing(id: number): Promise<Listing | undefined>;
  createListing(listing: InsertListing): Promise<Listing>;
  updateListingStatus(id: number, status: string): Promise<Listing | undefined>;
  searchListings(query: string): Promise<Listing[]>;
  getListingsBySeller(seller: string): Promise<Listing[]>;

  // Transaction operations
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactionsByUser(address: string): Promise<Transaction[]>;
  updateTransactionStatus(id: number, status: string, txHash?: string): Promise<Transaction | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private listings: Map<number, Listing>;
  private transactions: Map<number, Transaction>;
  private currentUserId: number;
  private currentListingId: number;
  private currentTransactionId: number;

  constructor() {
    this.users = new Map();
    this.listings = new Map();
    this.transactions = new Map();
    this.currentUserId = 1;
    this.currentListingId = 1;
    this.currentTransactionId = 1;

    // Add demo data
    this.createUser({
      username: "demo",
      password: "demo",
      walletAddress: "0x1",
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByWallet(address: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.walletAddress === address
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getListings(): Promise<Listing[]> {
    return Array.from(this.listings.values());
  }

  async getListing(id: number): Promise<Listing | undefined> {
    return this.listings.get(id);
  }

  async createListing(insertListing: InsertListing): Promise<Listing> {
    const id = this.currentListingId++;
    const listing: Listing = {
      ...insertListing,
      id,
      status: "available",
      createdAt: new Date(),
    };
    this.listings.set(id, listing);
    return listing;
  }

  async updateListingStatus(id: number, status: string): Promise<Listing | undefined> {
    const listing = this.listings.get(id);
    if (listing) {
      const updatedListing = { ...listing, status };
      this.listings.set(id, updatedListing);
      return updatedListing;
    }
    return undefined;
  }

  async searchListings(query: string): Promise<Listing[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.listings.values()).filter(
      (listing) =>
        listing.title.toLowerCase().includes(lowerQuery) ||
        listing.description.toLowerCase().includes(lowerQuery)
    );
  }

  async getListingsBySeller(seller: string): Promise<Listing[]> {
    return Array.from(this.listings.values()).filter(
      (listing) => listing.seller === seller
    );
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.currentTransactionId++;
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      status: "pending",
      createdAt: new Date(),
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async getTransactionsByUser(address: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      (tx) => tx.buyer === address || tx.seller === address
    );
  }

  async updateTransactionStatus(
    id: number,
    status: string,
    txHash?: string
  ): Promise<Transaction | undefined> {
    const transaction = this.transactions.get(id);
    if (transaction) {
      const updatedTransaction = { ...transaction, status, txHash };
      this.transactions.set(id, updatedTransaction);
      return updatedTransaction;
    }
    return undefined;
  }
}

export const storage = new MemStorage();