import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Trash2, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { purchaseListing } from "@/lib/aptos";
import { apiRequest } from "@/lib/queryClient";
import { getCurrentWalletAddress } from "@/lib/aptos";
import type { Listing } from "@shared/schema";

export default function ListingPage() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const currentAddress = getCurrentWalletAddress();

  const { data: listing, isLoading } = useQuery<Listing>({
    queryKey: [`/api/listings/${id}`],
  });

  const { mutate: purchase, isPending: isPurchasePending } = useMutation({
    mutationFn: async () => {
      if (!listing) return;
      const txHash = await purchaseListing({
        id: listing.id,
        price: Number(listing.price),
        seller: listing.seller,
      });
      await apiRequest("POST", "/api/transactions", {
        listingId: listing.id,
        buyer: currentAddress,
        seller: listing.seller,
        price: listing.price,
        status: "completed",
      });
      return txHash;
    },
    onSuccess: (txHash) => {
      toast({
        title: "Purchase Successful",
        description: `Transaction hash: ${txHash}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Purchase Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const { mutate: deleteListing, isPending: isDeletePending } = useMutation({
    mutationFn: async () => {
      if (!listing) return;
      await apiRequest("DELETE", `/api/listings/${listing.id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "NFT deleted successfully",
      });
      navigate("/marketplace");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this NFT? This action cannot be undone.")) {
      deleteListing();
    }
  };

  if (isLoading || !listing) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Card className="animate-pulse">
          <div className="h-96 bg-muted rounded-t-lg" />
          <CardContent className="p-6">
            <div className="h-8 bg-muted rounded w-3/4" />
            <div className="h-4 bg-muted rounded w-1/2 mt-4" />
            <div className="h-20 bg-muted rounded mt-4" />
          </CardContent>
        </Card>
      </div>
    );
  }

  const isOwner = currentAddress && currentAddress === listing.seller;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <Card>
        <img
          src={listing.image}
          alt={listing.title}
          className="w-full h-96 object-cover rounded-t-lg"
        />
        <CardHeader>
          <CardTitle className="text-3xl">{listing.title}</CardTitle>
          <p className="text-xl font-bold text-primary">{listing.price} APT</p>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground whitespace-pre-wrap">
            {listing.description}
          </p>
          <div className="mt-4">
            <p className="text-sm text-muted-foreground">
              Seller: {listing.seller}
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex gap-4">
          {!isOwner && (
            <Button
              className="flex-1"
              size="lg"
              onClick={() => purchase()}
              disabled={isPurchasePending || !listing.active}
            >
              {isPurchasePending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                "Purchase Now"
              )}
            </Button>
          )}
          {isOwner && (
            <Button
              variant="destructive"
              size="lg"
              onClick={handleDelete}
              disabled={isDeletePending}
              className="flex-1"
            >
              {isDeletePending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete NFT
                </>
              )}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}