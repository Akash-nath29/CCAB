import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import WalletButton from "./wallet-button";

export default function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link href="/">
              <a className="flex items-center">
                <span className="text-xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
                  Aptos Market
                </span>
              </a>
            </Link>
            
            <div className="ml-10 flex items-center space-x-4">
              <Link href="/">
                <a className={`px-3 py-2 rounded-md text-sm font-medium ${
                  location === "/" ? "text-primary" : "text-muted-foreground hover:text-primary"
                }`}>
                  Browse
                </a>
              </Link>
              <Link href="/create">
                <a className={`px-3 py-2 rounded-md text-sm font-medium ${
                  location === "/create" ? "text-primary" : "text-muted-foreground hover:text-primary"
                }`}>
                  Create Listing
                </a>
              </Link>
            </div>
          </div>
          
          <div className="flex items-center">
            <WalletButton />
          </div>
        </div>
      </div>
    </nav>
  );
}
