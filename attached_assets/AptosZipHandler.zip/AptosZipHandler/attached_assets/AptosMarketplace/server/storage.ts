import { type User, type InsertUser, type Listing, type InsertListing, type Transaction, type InsertTransaction } from "@shared/schema";

export interface IStorage {
  // Users
  getUser(address: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Listings
  getListing(id: number): Promise<Listing | undefined>;
  getListings(): Promise<Listing[]>;
  createListing(listing: InsertListing): Promise<Listing>;
  updateListing(id: number, active: boolean): Promise<Listing | undefined>;
  deleteListing(id: number): Promise<boolean>;

  // Transactions
  getTransaction(id: number): Promise<Transaction | undefined>;
  getTransactionsByAddress(address: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransactionStatus(id: number, status: string): Promise<Transaction | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private listings: Map<number, Listing>;
  private transactions: Map<number, Transaction>;
  private listingId: number;
  private transactionId: number;

  constructor() {
    this.users = new Map();
    this.listings = new Map();
    this.transactions = new Map();
    this.listingId = 1;
    this.transactionId = 1;
  }

  async getUser(address: string): Promise<User | undefined> {
    return this.users.get(address);
  }

  async createUser(user: InsertUser): Promise<User> {
    const newUser = { ...user, id: this.users.size + 1 };
    this.users.set(user.address, newUser);
    return newUser;
  }

  async getListing(id: number): Promise<Listing | undefined> {
    return this.listings.get(id);
  }

  async getListings(): Promise<Listing[]> {
    return Array.from(this.listings.values());
  }

  async createListing(listing: InsertListing): Promise<Listing> {
    const id = this.listingId++;
    const newListing = {
      ...listing,
      id,
      createdAt: new Date(),
    };
    this.listings.set(id, newListing);
    return newListing;
  }

  async updateListing(id: number, active: boolean): Promise<Listing | undefined> {
    const listing = this.listings.get(id);
    if (!listing) return undefined;

    const updatedListing = { ...listing, active };
    this.listings.set(id, updatedListing);
    return updatedListing;
  }

  async deleteListing(id: number): Promise<boolean> {
    return this.listings.delete(id);
  }

  async getTransaction(id: number): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }

  async getTransactionsByAddress(address: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      (tx) => tx.buyer === address || tx.seller === address
    );
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionId++;
    const newTransaction = {
      ...transaction,
      id,
      createdAt: new Date(),
    };
    this.transactions.set(id, newTransaction);
    return newTransaction;
  }

  async updateTransactionStatus(id: number, status: string): Promise<Transaction | undefined> {
    const transaction = this.transactions.get(id);
    if (!transaction) return undefined;

    const updatedTransaction = { ...transaction, status };
    this.transactions.set(id, updatedTransaction);
    return updatedTransaction;
  }
}

export const storage = new MemStorage();