import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertListingSchema, insertTransactionSchema, insertUserSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Users
  app.post("/api/users", async (req, res) => {
    const result = insertUserSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const user = await storage.createUser(result.data);
    res.json(user);
  });

  app.get("/api/users/:address", async (req, res) => {
    const user = await storage.getUser(req.params.address);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(user);
  });

  // Listings
  app.get("/api/listings", async (_req, res) => {
    const listings = await storage.getListings();
    res.json(listings);
  });

  app.get("/api/listings/:id", async (req, res) => {
    const listing = await storage.getListing(parseInt(req.params.id));
    if (!listing) {
      return res.status(404).json({ error: "Listing not found" });
    }
    res.json(listing);
  });

  app.post("/api/listings", async (req, res) => {
    const result = insertListingSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const listing = await storage.createListing(result.data);
    res.json(listing);
  });

  app.patch("/api/listings/:id", async (req, res) => {
    const listing = await storage.updateListing(
      parseInt(req.params.id),
      req.body.active
    );
    if (!listing) {
      return res.status(404).json({ error: "Listing not found" });
    }
    res.json(listing);
  });

  app.delete("/api/listings/:id", async (req, res) => {
    const success = await storage.deleteListing(parseInt(req.params.id));
    if (!success) {
      return res.status(404).json({ error: "Listing not found" });
    }
    res.status(204).send();
  });

  // Transactions
  app.get("/api/transactions/:address", async (req, res) => {
    const transactions = await storage.getTransactionsByAddress(req.params.address);
    res.json(transactions);
  });

  app.post("/api/transactions", async (req, res) => {
    const result = insertTransactionSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const transaction = await storage.createTransaction(result.data);
    res.json(transaction);
  });

  const httpServer = createServer(app);
  return httpServer;
}